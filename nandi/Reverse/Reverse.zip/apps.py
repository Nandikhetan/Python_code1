from django.apps import AppConfig


class ReverseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Reverse'
